const cohorts = [
    {id:1,name:"Kare",noOfStudents:15,start_date:"23/09/21",finish_date:"19/11/21"},
    {id:2,name:"Kurita",noOfStudents:12,start_date:"20/08/21",finish_date:"15/10/21"},
    {id:3,name:"Hamilton",noOfStudents:15,start_date:"23/02/21",finish_date:"10/05/21"},
    {id:4,name:"Morris",noOfStudents:18,start_date:"15/07/21",finish_date:"10/09/21"},
    {id:5,name:"Jackson",noOfStudents:21,start_date:"23/08/20",finish_date:"02/10/20"},
    {id:6,name:"Kare",noOfStudents:25,start_date:"23/09/21",finish_date:"19/11/21"}
]

module.exports = cohorts;       